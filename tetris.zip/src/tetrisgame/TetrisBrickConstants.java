/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tetrisgame;

/**
 *
 * @author JAHNICS
 */
public interface TetrisBrickConstants {
    final static int BOX = 1;
    final static int RIGHT_L = 2;
    final static int LEFT_L = 3;
    final static int LEFT_Z = 4;
    final static int RIGHT_Z = 5;
    final static int STANDING = 6;
    final static int UP = 1;
    final static int RIGHT = 2;
    final static int DOWN = 3;
    final static int LEFT = 4;
}
